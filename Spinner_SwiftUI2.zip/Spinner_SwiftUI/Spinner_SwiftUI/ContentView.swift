//
//  ContentView.swift
//  Spinner_SwiftUI
//
//  Created by Anthony Codes on 22/08/2020.
//

import SwiftUI

struct ContentView: View {
    
    @State private var spinXLarge = false
    @State private var spinMedium = false
    @State private var spinXSmall = false
    
    var body: some View {
        VStack(alignment: .center, spacing: 40) {
            Text("Spinners in SwiftUI")
                .font(.system(size: 25, weight: .heavy, design: .serif))
            VStack {
                HStack {
                    Circle()
                        .trim(from: 1/4, to: 1)
                        .stroke(style: StrokeStyle(lineWidth: 10, lineCap: .round, lineJoin: .round))
                        .foregroundColor(.green)
                        .frame(width: 50, height: 50)
                        .rotationEffect(.degrees(spinXLarge ? 360 : 0))
                        .animation(Animation.linear(duration: 1).repeatForever(autoreverses: false))
                        .onAppear {
                            self.spinXLarge = true
                        }
                    Text("Large Spinner")
                        .font(.title)
                        .padding(.leading, 25)
                }
                
                HStack {
                    Circle()
                        .trim(from: 1/2, to: 1)
                        .stroke(style: StrokeStyle(lineWidth: 6, lineCap: .round, lineJoin: .round))
                        .foregroundColor(.red)
                        .frame(width: 90, height: 90)
                        .rotationEffect(.degrees(spinMedium ? 360 : 0))
                        .animation(Animation.linear(duration: 1).repeatForever(autoreverses: false))
                        .onAppear {
                            self.spinMedium = true
                        }
                    Text("Medium Half Spinner")
                        .font(.title)
                        .padding(.leading, 25)
                }
                
                
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
